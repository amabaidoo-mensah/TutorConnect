# TutorConnect (React + TypeScript + Supabase + Paystack)
1. `npm install` then copy `.env.example` to `.env` and fill in your Supabase URL and anon key.
2. In Supabase SQL editor run `supabase/migrations/001_schema.sql`. Insert institutions, courses; promote your admin: `update profiles set role='admin' where id='<uuid>'`.
3. Deploy the function: `supabase functions deploy payments` and `supabase secrets set PAYSTACK_SECRET=sk_test_...`. In Paystack (test mode) set the webhook URL to the function URL.
4. `npm run dev`.
Security model: contacts sit in `tutor_contacts`, readable only through RLS after a paid unlock row exists; payments, unlocks and premium are written only by the Edge Function using the service-role key.
Not yet built here: tutor/admin dashboards, reviews/reports UI, avatar uploads (the schema, RLS and `admin_set_tutor_status` already support them). Not tested against a live Supabase or Paystack project.
