import { useEffect, useState, FormEvent } from "react";
import { supabase } from "./supabase";
type Tutor = { id: string; name: string; bio: string; rate: number; delivery: string; course_code: string; avg_rating: number | null; review_count: number; featured: boolean };
type Inst = { id: number; name: string };
const call = async (body: object) => (await supabase.functions.invoke("payments", { body })).data;

export default function App() {
  const [user, setUser] = useState<any>(null), [insts, setInsts] = useState<Inst[]>([]), [inst, setInst] = useState(1), [q, setQ] = useState("");
  const [rows, setRows] = useState<Tutor[]>([]), [contacts, setContacts] = useState<Record<string, any>>({}), [msg, setMsg] = useState("");
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    supabase.from("institutions").select("id,name").then(({ data }) => { if (data?.length) { setInsts(data); setInst(data[0].id); } });
    const ref = new URLSearchParams(location.search).get("reference"); // back from Paystack: the server verifies, not the browser
    if (ref) call({ action: "verify", reference: ref }).then((r) => { setMsg(r?.status === "paid" ? "Payment verified. Contact unlocked." : "Payment not completed. Nothing was unlocked."); history.replaceState({}, "", "/"); });
  }, []);
  async function loadContacts() { const { data } = await supabase.from("tutor_contacts").select("*"); // RLS returns only rows this student has paid to unlock
    setContacts(Object.fromEntries((data ?? []).map((c) => [c.tutor_id, c]))); }
  async function search(e: FormEvent) { e.preventDefault(); const { data } = await supabase.rpc("search_tutors", { p_institution: inst, p_query: q }); setRows(data ?? []); loadContacts(); }
  async function unlock(id: string) { const r = await call({ action: "contact", tutor_id: id, callback_url: location.origin }); if (r?.url) location.href = r.url; else setMsg("Could not start payment. Try again."); }
  async function auth(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); const f = new FormData(e.currentTarget), email = String(f.get("e")), password = String(f.get("p"));
    const signUp = ((e.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null)?.name === "up";
    const { error } = signUp ? await supabase.auth.signUp({ email, password, options: { data: { full_name: f.get("n") } } }) : await supabase.auth.signInWithPassword({ email, password });
    setMsg(error?.message ?? "");
  }
  return <main style={{ maxWidth: 720, margin: "0 auto", padding: 16, font: "16px system-ui" }}>
    <h1>TutorConnect</h1>{msg && <p role="status">{msg}</p>}
    {!user ? <form onSubmit={auth}><input name="n" placeholder="Full name (sign up)" /><input name="e" type="email" placeholder="Email" required /><input name="p" type="password" placeholder="Password" required />
      <button>Log in</button> <button name="up">Sign up</button></form> : <p>{user.email} <button onClick={() => supabase.auth.signOut()}>Log out</button></p>}
    <form onSubmit={search}><select value={inst} onChange={(e) => setInst(+e.target.value)}>{insts.map((i) => <option key={i.id} value={i.id}>{i.name}</option>)}</select>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Course code or title" required /><button>Search tutors</button></form>
    {rows.map((t) => <article key={t.id} style={{ border: "1px solid #ccc", borderRadius: 10, padding: 12, margin: "10px 0" }}>
      <b>{t.name}</b> {t.featured && <mark>Featured</mark>}<br /><small>{t.course_code} · GHS {t.rate}/hr · {t.delivery} · {t.avg_rating ? `★ ${(+t.avg_rating).toFixed(1)} (${t.review_count})` : "No reviews yet"}</small><p>{t.bio}</p>
      {contacts[t.id] ? <p>📞 {contacts[t.id].phone} · ✉️ {contacts[t.id].email}</p> : user && <button onClick={() => unlock(t.id)}>Unlock contact (GHS 10)</button>}</article>)}
  </main>;
}
